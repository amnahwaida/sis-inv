--
-- PostgreSQL database dump
--

\restrict ueE9FMsHfD7hinIUYxfZAX5WCSl6ewCpPveoJDeBN9zUcarxomve7e0EVqrXpDd

-- Dumped from database version 15.16
-- Dumped by pg_dump version 15.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: sekolah_admin
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    entity_type character varying(50),
    entity_id uuid,
    old_value jsonb,
    new_value jsonb,
    ip_address character varying(45),
    user_agent character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.audit_logs OWNER TO sekolah_admin;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: sekolah_admin
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO sekolah_admin;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sekolah_admin
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: sekolah_admin
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color_code character varying(7),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categories OWNER TO sekolah_admin;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: sekolah_admin
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO sekolah_admin;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sekolah_admin
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: sekolah_admin
--

CREATE TABLE public.items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    qr_code_data character varying(255),
    name character varying(255) NOT NULL,
    category_id integer,
    location character varying(100),
    condition character varying(20) DEFAULT 'GOOD'::character varying,
    status character varying(20) DEFAULT 'AVAILABLE'::character varying,
    borrower_type character varying(20) DEFAULT 'STAFF_ONLY'::character varying,
    purchase_date date,
    purchase_price numeric(15,2),
    warranty_end_date date,
    notes text,
    photo_url character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT items_borrower_type_check CHECK (((borrower_type)::text = ANY ((ARRAY['STAFF_ONLY'::character varying, 'STUDENT_ALLOWED'::character varying])::text[]))),
    CONSTRAINT items_condition_check CHECK (((condition)::text = ANY ((ARRAY['GOOD'::character varying, 'DAMAGED'::character varying, 'LOST'::character varying, 'IN_REPAIR'::character varying])::text[]))),
    CONSTRAINT items_status_check CHECK (((status)::text = ANY ((ARRAY['AVAILABLE'::character varying, 'BORROWED'::character varying, 'MAINTENANCE'::character varying, 'LOST'::character varying])::text[])))
);


ALTER TABLE public.items OWNER TO sekolah_admin;

--
-- Name: maintenance_logs; Type: TABLE; Schema: public; Owner: sekolah_admin
--

CREATE TABLE public.maintenance_logs (
    id integer NOT NULL,
    item_id uuid,
    reported_by uuid,
    reported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    issue_description text NOT NULL,
    cost numeric(15,2),
    vendor character varying(100),
    status character varying(20) DEFAULT 'PENDING'::character varying,
    completed_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT maintenance_logs_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'DONE'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.maintenance_logs OWNER TO sekolah_admin;

--
-- Name: maintenance_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: sekolah_admin
--

CREATE SEQUENCE public.maintenance_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.maintenance_logs_id_seq OWNER TO sekolah_admin;

--
-- Name: maintenance_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sekolah_admin
--

ALTER SEQUENCE public.maintenance_logs_id_seq OWNED BY public.maintenance_logs.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: sekolah_admin
--

CREATE TABLE public.students (
    id integer NOT NULL,
    nis character varying(50) NOT NULL,
    full_name character varying(100) NOT NULL,
    class character varying(20),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.students OWNER TO sekolah_admin;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: sekolah_admin
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.students_id_seq OWNER TO sekolah_admin;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sekolah_admin
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: sekolah_admin
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid,
    borrower_type character varying(10) NOT NULL,
    user_id uuid,
    student_nis character varying(50),
    student_name character varying(100),
    student_class character varying(20),
    borrowed_by uuid NOT NULL,
    borrowed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    due_date timestamp without time zone NOT NULL,
    returned_at timestamp without time zone,
    status character varying(20) DEFAULT 'ACTIVE'::character varying,
    purpose text,
    return_condition character varying(20),
    return_notes text,
    return_photo_url character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT transactions_borrower_type_check CHECK (((borrower_type)::text = ANY ((ARRAY['STAFF'::character varying, 'STUDENT'::character varying])::text[]))),
    CONSTRAINT transactions_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'RETURNED'::character varying, 'OVERDUE'::character varying])::text[])))
);


ALTER TABLE public.transactions OWNER TO sekolah_admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: sekolah_admin
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    role character varying(20) NOT NULL,
    nip character varying(50),
    email character varying(100),
    phone character varying(20),
    is_active boolean DEFAULT true,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['ADMIN'::character varying, 'TEACHER'::character varying, 'HEAD'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO sekolah_admin;

--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: maintenance_logs id; Type: DEFAULT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.maintenance_logs ALTER COLUMN id SET DEFAULT nextval('public.maintenance_logs_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: sekolah_admin
--

COPY public.audit_logs (id, user_id, action, entity_type, entity_id, old_value, new_value, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: sekolah_admin
--

COPY public.categories (id, name, description, color_code, created_at) FROM stdin;
1	Elektronik	Peralatan elektronik (proyektor, laptop, dll)	#2196F3	2026-03-29 01:13:31.223073
2	Furniture	Meja, kursi, lemari	#795548	2026-03-29 01:13:31.227489
3	Alat Lab	Peralatan laboratorium	#9C27B0	2026-03-29 01:13:31.231337
4	Olahraga	Peralatan olahraga	#4CAF50	2026-03-29 01:13:31.235306
5	ATK	Alat tulis kantor	#FF9800	2026-03-29 01:13:31.239044
6	Lainnya	Kategori lain-lain	#607D8B	2026-03-29 01:13:31.242504
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: sekolah_admin
--

COPY public.items (id, code, qr_code_data, name, category_id, location, condition, status, borrower_type, purchase_date, purchase_price, warranty_end_date, notes, photo_url, created_at, updated_at) FROM stdin;
35e8face-bdae-4f67-807a-c73ead81ae01	TEST-123	TEST-123	Test Laptop	\N	\N	GOOD	AVAILABLE	STAFF_ONLY	\N	\N	\N	\N	\N	2026-03-29 02:10:36.224323	2026-03-29 02:19:08.583632
\.


--
-- Data for Name: maintenance_logs; Type: TABLE DATA; Schema: public; Owner: sekolah_admin
--

COPY public.maintenance_logs (id, item_id, reported_by, reported_at, issue_description, cost, vendor, status, completed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: sekolah_admin
--

COPY public.students (id, nis, full_name, class, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: sekolah_admin
--

COPY public.transactions (id, item_id, borrower_type, user_id, student_nis, student_name, student_class, borrowed_by, borrowed_at, due_date, returned_at, status, purpose, return_condition, return_notes, return_photo_url, created_at, updated_at) FROM stdin;
f0ea6614-9043-4a72-bbaf-7ce62d1086f9	35e8face-bdae-4f67-807a-c73ead81ae01	STAFF	09e44005-d38d-401f-8ad3-46f634293f10	\N	\N	\N	09e44005-d38d-401f-8ad3-46f634293f10	2026-03-29 02:18:54.615512	2026-04-05 09:18:54.621903	2026-03-29 09:19:08.589007	RETURNED	Testing borrow	GOOD	Testing return	\N	2026-03-29 02:18:54.615512	2026-03-29 02:19:08.583632
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sekolah_admin
--

COPY public.users (id, username, password_hash, full_name, role, nip, email, phone, is_active, last_login, created_at, updated_at) FROM stdin;
09e44005-d38d-401f-8ad3-46f634293f10	admin	$2a$12$UEvG3boZtJgrF6RfAQlmzOMSw2HpEf0Z6R8yMM8S0.umSc4BZvEYu	Administrator	ADMIN	\N	\N	\N	t	2026-03-29 09:10:29.649766	2026-03-29 01:13:31.215067	2026-03-29 01:13:31.215067
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sekolah_admin
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sekolah_admin
--

SELECT pg_catalog.setval('public.categories_id_seq', 6, true);


--
-- Name: maintenance_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sekolah_admin
--

SELECT pg_catalog.setval('public.maintenance_logs_id_seq', 1, false);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sekolah_admin
--

SELECT pg_catalog.setval('public.students_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: items items_code_key; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_code_key UNIQUE (code);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: maintenance_logs maintenance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.maintenance_logs
    ADD CONSTRAINT maintenance_logs_pkey PRIMARY KEY (id);


--
-- Name: students students_nis_key; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_nis_key UNIQUE (nis);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_audit_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_audit_user ON public.audit_logs USING btree (user_id);


--
-- Name: idx_items_borrower_type; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_items_borrower_type ON public.items USING btree (borrower_type);


--
-- Name: idx_items_category; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_items_category ON public.items USING btree (category_id);


--
-- Name: idx_items_location; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_items_location ON public.items USING btree (location);


--
-- Name: idx_items_status; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_items_status ON public.items USING btree (status);


--
-- Name: idx_maintenance_item; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_maintenance_item ON public.maintenance_logs USING btree (item_id);


--
-- Name: idx_maintenance_status; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_maintenance_status ON public.maintenance_logs USING btree (status);


--
-- Name: idx_students_class; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_students_class ON public.students USING btree (class);


--
-- Name: idx_students_name; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_students_name ON public.students USING btree (full_name);


--
-- Name: idx_students_nis; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_students_nis ON public.students USING btree (nis);


--
-- Name: idx_transactions_borrowed_by; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_transactions_borrowed_by ON public.transactions USING btree (borrowed_by);


--
-- Name: idx_transactions_due_date; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_transactions_due_date ON public.transactions USING btree (due_date);


--
-- Name: idx_transactions_item; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_transactions_item ON public.transactions USING btree (item_id);


--
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- Name: idx_transactions_student; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_transactions_student ON public.transactions USING btree (student_nis);


--
-- Name: idx_transactions_user; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_transactions_user ON public.transactions USING btree (user_id);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: sekolah_admin
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: maintenance_logs maintenance_logs_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.maintenance_logs
    ADD CONSTRAINT maintenance_logs_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: maintenance_logs maintenance_logs_reported_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.maintenance_logs
    ADD CONSTRAINT maintenance_logs_reported_by_fkey FOREIGN KEY (reported_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_borrowed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_borrowed_by_fkey FOREIGN KEY (borrowed_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sekolah_admin
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict ueE9FMsHfD7hinIUYxfZAX5WCSl6ewCpPveoJDeBN9zUcarxomve7e0EVqrXpDd

